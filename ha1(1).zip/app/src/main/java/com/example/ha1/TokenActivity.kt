package com.example.ha1

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import com.bumptech.glide.Glide

class TokenActivity : AppCompatActivity() {

    companion object {
        const val gs = "https://chart.googleapis.com/chart"
        const val qrSize = "300x300"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_token)
        val intent = intent
//        intent.putExtra("login", MainActivity.login)

//        val content = "bitcoin:3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy"
//
//        val writer = QRCodeWriter()
//        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, 512, 512)
//        val width = bitMatrix.width
//        val height = bitMatrix.height
//        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
//        for (x in 0 until width) {
//            for (y in 0 until height) {
//                bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
//            }
//        }

        val imageView = ImageView(this)
        Glide.
            with(this).
            load(
                gs.
                    plus("?chs=").
                    plus(qrSize).
                    plus("&cht=qr&chl=").
                    plus(MainActivity.server).
                    plus("access/check_in?token=").
                    plus(intent.getStringExtra("token")).
                    plus("_amp;").
                    plus(intent.getLongExtra("ts", 0)).
                    plus("_amp;").
                    plus(intent.getLongExtra("r", 0)).
                    plus("_amp;").
                    plus(MainActivity.login)
//                "https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=http://ha1.loc/access/check_in?token=549d178456fd867aadd4f0247f64954a96f700e5_amp;1576261571_amp;837276159_amp;zxc"
            ).
            into(imageView)
//        imageView.setImageBitmap(bitmap)
        val constraintLayout = findViewById<ConstraintLayout>(R.id.constraintLayout)
        constraintLayout.addView(imageView)
    }
}
