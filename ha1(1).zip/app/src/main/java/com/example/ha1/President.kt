package com.example.ha1

data class President(val id: Int, val name: String, val politic: String, val time: String) {
}