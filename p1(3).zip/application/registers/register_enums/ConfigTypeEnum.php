<?php
/**
 * Created by PhpStorm.
 * User: Borys Plotka ( @3plo )
 * Date: 30.11.2019
 * Time: 23:17
 */

namespace application\registers\register_enums;


class ConfigTypeEnum
{
    const DEFAULT = 'DEFAULT';
}