<?php
/**
 * Created by PhpStorm.
 * User: Borys Plotka ( @3plo )
 * Date: 30.11.2019
 * Time: 23:14
 */

namespace application\strategies\application_strategies;


interface ApplicationInitStrategyInterface
{
    /**
     * @author Borys Plotka ( @3plo )
     */
    public function applicationInit();
}