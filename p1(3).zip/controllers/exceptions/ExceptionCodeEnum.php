<?php
/**
 * Created by PhpStorm.
 * User: Borys Plotka ( @3plo )
 * Date: 30.11.2019
 * Time: 23:31
 */

namespace controllers\exceptions;


class ExceptionCodeEnum
{
    const DEFAULT = 'default';
    const ROUTING_EXCEPTION_CODE = 200000;
    const INCORRECT_CONTROLLER_PATH = 200001;
}