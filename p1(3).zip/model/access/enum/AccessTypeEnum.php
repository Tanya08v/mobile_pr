<?php
/**
 * Created by PhpStorm.
 * User: Borys Plotka ( @3plo )
 * Date: 01.12.2019
 * Time: 19:02
 */

namespace model\access\enum;


class AccessTypeEnum
{
    const IN = 1;
    const OUT = 2;
}