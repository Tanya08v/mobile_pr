<?php
/**
 * Created by PhpStorm.
 * User: Borys Plotka ( @3plo )
 * Date: 01.12.2019
 * Time: 11:14
 */

namespace model\user\enum;


class UserTypeEnum
{
    const STUDENT = 1;
    const ACCESS_POINT = 2;
    const PERSONAL = 3;
    const GUEST = 4;
}