<?php
/**
 * Created by PhpStorm.
 * User: Borys Plotka ( @3plo )
 * Date: 05.12.2019
 * Time: 21:56
 */

namespace model\department;


use model\Model;

class Department extends Model
{
    protected $mainTable = 'department';
}